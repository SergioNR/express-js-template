(function() {
  window._POSTHOG_REMOTE_CONFIG = window._POSTHOG_REMOTE_CONFIG || {};
  window._POSTHOG_REMOTE_CONFIG['phc_o6Irh4IJIejYBaZCnS115xMx05UMMLekRsQjZSbJ4O8'] = {
    config: {"token": "phc_o6Irh4IJIejYBaZCnS115xMx05UMMLekRsQjZSbJ4O8", "supportedCompression": ["gzip", "gzip-js"], "hasFeatureFlags": true, "captureDeadClicks": false, "capturePerformance": {"network_timing": true, "web_vitals": true, "web_vitals_allowed_metrics": null}, "autocapture_opt_out": false, "autocaptureExceptions": false, "analytics": {"endpoint": "/i/v0/e/"}, "elementsChainAsString": true, "sessionRecording": {"endpoint": "/s/", "consoleLogRecordingEnabled": true, "recorderVersion": "v2", "sampleRate": null, "minimumDurationMilliseconds": null, "linkedFlag": null, "networkPayloadCapture": null, "urlTriggers": [], "urlBlocklist": [], "eventTriggers": [], "scriptConfig": null}, "heatmaps": true, "surveys": [], "defaultIdentifiedOnly": true},
    siteApps: []
  }
})();